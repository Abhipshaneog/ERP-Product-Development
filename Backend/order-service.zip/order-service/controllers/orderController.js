const orderService = require('../services/orderService');

// Create new order
exports.createOrder = async (req, res) => {
    try {
        const order = await orderService.createOrder(req.body);
        res.status(201).json(order);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get order by ID
exports.getOrderById = async (req, res) => {
    try {
        const order = await orderService.getOrderById(req.params.id);
        if (!order) return res.status(404).json({ message: 'Order not found' });
        res.json(order);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update order status
exports.updateOrderStatus = async (req, res) => {
    try {
        const order = await orderService.updateOrderStatus(req.params.id, req.body.status, req.body.changed_by);
        res.json(order);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Add note to order
exports.addOrderNote = async (req, res) => {
    try {
        const note = await orderService.addOrderNote(req.params.id, req.body.note, req.body.created_by);
        res.status(201).json(note);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// List orders with optional filters (by user, status, etc.)
exports.listOrders = async (req, res) => {
    try {
        const orders = await orderService.listOrders(req.query);
        res.json(orders);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
