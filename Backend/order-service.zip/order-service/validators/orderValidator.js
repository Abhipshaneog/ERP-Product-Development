const { body, param } = require('express-validator');

const validStatuses = ['PENDING', 'PAID', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED'];

const createOrderValidator = [
    body('user_id').isUUID(),
    body('total_amount').isFloat({ min: 0.01 }),
    body('status').optional().isIn(validStatuses),
    body('items').isArray().withMessage('Items must be an array').notEmpty(),
    body('items.*.product_id').isUUID().withMessage('Each item must have a valid product_id'),
    body('items.*.quantity').isInt({ min: 1 }).withMessage('Each item must have a quantity of at least 1'),
];

const updateOrderStatusValidator = [
    param('id').isUUID(),
    body('status').isIn(validStatuses),
];

module.exports = {
    createOrderValidator,
    updateOrderStatusValidator
};
