const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');
const Order = require('./orderModel');

const OrderAuditLog = sequelize.define('OrderAuditLog', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    order_id: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
            model: Order,
            key: 'id'
        }
    },
    status: {
        type: DataTypes.STRING(50),
        allowNull: false,
        validate: {
            isIn: [['PENDING', 'PAID', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED']]
        }
    },
    changed_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    changed_by: {
        type: DataTypes.STRING(255),
        defaultValue: 'SYSTEM'
    }
}, {
    tableName: 'order_audit_logs',
    timestamps: false
});

module.exports = OrderAuditLog;
