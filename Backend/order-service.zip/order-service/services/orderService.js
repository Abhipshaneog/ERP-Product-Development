const { Order, OrderItem, OrderAuditLog, OrderNote } = require('../models');  // Combined model index
const { Sequelize } = require('sequelize');

async function createOrder(orderData) {
    const transaction = await Order.sequelize.transaction();
    try {
        const { items, user_id, total_amount } = orderData;

        // Create order
        const order = await Order.create(
            { user_id, total_amount },
            { transaction }
        );

        // Create order items
        const orderItems = await Promise.all(items.map(item =>
            OrderItem.create({ ...item, order_id: order.id }, { transaction })
        ));

        // Create initial audit log
        await OrderAuditLog.create({
            order_id: order.id,
            status: 'PENDING',
            changed_by: orderData.created_by || 'SYSTEM'
        }, { transaction });

        await transaction.commit();

        return { order, orderItems };
    } catch (error) {
        await transaction.rollback();
        throw error;
    }
}

async function getOrderById(orderId) {
    return await Order.findByPk(orderId, {
        include: [
            { model: OrderItem },
            { model: OrderAuditLog },
            { model: OrderNote }
        ]
    });
}

async function updateOrderStatus(orderId, newStatus, changedBy = 'SYSTEM') {
    const transaction = await Order.sequelize.transaction();
    try {
        const order = await Order.findByPk(orderId, { transaction });
        if (!order) {
            throw new Error('Order not found');
        }

        // Update order status
        order.status = newStatus;
        await order.save({ transaction });

        // Add audit log entry
        await OrderAuditLog.create({
            order_id: orderId,
            status: newStatus,
            changed_by: changedBy
        }, { transaction });

        await transaction.commit();

        return order;
    } catch (error) {
        await transaction.rollback();
        throw error;
    }
}

async function addOrderNote(orderId, note, createdBy = 'SYSTEM') {
    const order = await Order.findByPk(orderId);
    if (!order) {
        throw new Error('Order not found');
    }

    const orderNote = await OrderNote.create({
        order_id: orderId,
        note,
        created_by: createdBy
    });

    return orderNote;
}

async function listOrders(query = {}) {
    const filters = {};

    if (query.user_id) {
        filters.user_id = query.user_id;
    }
    if (query.status) {
        filters.status = query.status;
    }

    return await Order.findAll({
        where: filters,
        include: [
            { model: OrderItem },
            { model: OrderAuditLog },
            { model: OrderNote }
        ],
        order: [['created_at', 'DESC']]
    });
}

module.exports = {
    createOrder,
    getOrderById,
    updateOrderStatus,
    addOrderNote,
    listOrders
};
