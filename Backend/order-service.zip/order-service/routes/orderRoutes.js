const express = require('express');
const router = express.Router();
const { body, param } = require('express-validator');
const orderController = require('../controllers/orderController');
const { validate } = require('../middlewares/validate'); 
const { createOrderValidator, updateOrderStatusValidator } = require('../validators/orderValidator');

console.log('Loaded orderController:', orderController); 
router.post('/',
    createOrderValidator,
    validate,
    orderController.createOrder
);

router.get('/:id',
    param('id').isUUID(),
    validate,
    orderController.getOrderById
);

router.patch('/:id/status',
    updateOrderStatusValidator,
    validate,
    orderController.updateOrderStatus
);

router.post('/:id/notes',
    param('id').isUUID(),
    body('note').notEmpty(),
    validate,
    orderController.addOrderNote
);

router.get('/', orderController.listOrders);

module.exports = router;
